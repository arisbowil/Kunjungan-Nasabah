PROYEK ANDROID KUNJUNGAN NASABAH
Versi 1.0

Target: APK Android.
Fitur dasar berasal dari PWA Kunjungan Nasabah:
- daftar nasabah
- belum/sudah dikunjungi
- profil
- foto
- lokasi GPS
- Maps
- catatan
- penyimpanan lokal

PENTING:
Folder ini adalah SOURCE PROJECT, bukan APK yang sudah dikompilasi.
Untuk menghasilkan APK diperlukan Android SDK/Gradle atau layanan build Android.